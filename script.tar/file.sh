#!/bin/bash 
# interpreter : 
echo "hello world"
read -p " enter your name: " abc 
echo $abc, welcome

