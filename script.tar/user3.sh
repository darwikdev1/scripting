#!/bin/bash
while read line;do
	userdel -r $line 
	echo $line deleted
done < users.list
