#!/bin/bash
while read line;do
	useradd $line 
	echo $line created
done < users.list
