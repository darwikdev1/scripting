#!/bin/bash
echo "creating file1 file2 file3"
touch file{1..3}
sleep 2
echo "inserting text in file2"
echo "hello world" > file2 
sleep 2
echo "creating directory named ted"
mkdir ted
sleep 2

echo "moving file1 file3 to ted directory"
mv file1 file3 ted 
sleep 2

echo "checking files in current location"
pwd;ls file2 
sleep 2

echo "output of the file2"
cat file2 
sleep 2
