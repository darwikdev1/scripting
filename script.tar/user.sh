read -p "enter username: " username 
echo -n "enter password: " 
read -s password
echo ""
if [[ ( $username == "redhat" && $password == "redhat"  ) ]];then
echo "user matched"
else
echo "user failed"
fi 

