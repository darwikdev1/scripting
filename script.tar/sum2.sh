#!/bin/bash
read -p "first digit: " a
read -p "second digit: " b
# Add two numeric value
((sum=a+b))

#Print the result
echo $sum
