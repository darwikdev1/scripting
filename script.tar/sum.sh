#!/bin/bash 
read -p "enter first digit: " a 
read -p "enter second digit: " b 
echo "total item is $[a-b]"
