systemctl is-active httpd &> /dev/null 
if [ $? -ne 0 ];then 
echo "httpd service has started"
systemctl restart httpd
else
 echo "httpd service has stopped"
systemctl stop httpd
fi
